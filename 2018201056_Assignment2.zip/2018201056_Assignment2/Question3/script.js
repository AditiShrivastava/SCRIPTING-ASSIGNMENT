 
      function DeleteRows() {
        var rowCount = char_table.rows.length;
        for (var i = rowCount - 1; i > 0; i--) {
              char_table.deleteRow(i);
        }
    }
      function fillTable()
      { 
        DeleteRows();
        //alert("inside req func ");
        var name=document.getElementById("searchtext").value;
        //alert("Search bar has "+name);
        name.replace(/ /g,"+");
        var url="https://anapioficeandfire.com/api/characters/?name="+name;
        $.getJSON(url, function(data)
        {
          $("#charname").html(data[0].name);
          var char_data = '';
          $.each(data,function(key,value){
            char_data +='<tr>';
            char_data +='<td>'+value.gender+'</td>';
            char_data +='<td>'+value.culture+'</td>';
            char_data +='<td>'+value.born+'</td>';
            char_data +='<td>'+value.died+'</td>';
            char_data +='<td>'+value.aliases+'</td>';
            char_data +='</tr>';
          });
          $('#char_table').append(char_data);
        });
      }

      function fillTablebyHouse()
      { 
        DeleteRows();
        // alert("inside req func ");
        var name=document.getElementById("searchtext").value;
        // alert("Search bar has "+name);
        name.replace(/ /g,"+");
        var url="https://anapioficeandfire.com/api/houses/?name="+name;
        $.getJSON(url, function(data)
        {
          var char_data = '';
          $.each(data,function(key,value){
            char_data +='<tr>';
            char_data +='<td>'+value.region+'</td>';
            char_data +='<td>'+value.coatOfArms+'</td>';
            char_data +='<td>'+value.words+'</td>';
            char_data +='<td>'+value.titles+'</td>';
            char_data +='<td>'+value.seats+'</td>';
            char_data +='<td>'+value.ancestralWeapons+'</td>';

            char_data +='</tr>';
          });
          $('#char_table').append(char_data);
        });
      }
      function myFunction() 
      {
          // alert('Hello');
      }
      function fillTablebyRandomCharacter()
      {
        DeleteRows();
        // alert("inside req func ");
        var random=Math.floor(Math.random() * (2138)) + 1;
        var url="https://anapioficeandfire.com/api/characters/"+random;
         // alert("url is"+url);
        $.getJSON(url,function(data)
        {
          // alert("inside");

          $("#charname").html(data.name);
          $("#chargender").html(data.gender);
          $("#charculture").html(data.culture);
          $("#charborn").html(data.born);
          $("#chardied").html(data.died);
          $("#charaliases").html(data.aliases);
          $("#charfather").html(data.father);
          $("#charmother").html(data.mother);
          $("#charspouse").html(data.spouse);
           $("#chartitle").html(data.titles);
     


        });

      }
      function fillTablebyRandomHouse()
      {
        DeleteRows();
        // alert("inside req func ");
        var random=Math.floor(Math.random() * (444)) + 1;
        var url="https://anapioficeandfire.com/api/houses/"+random;
         // alert("url is"+url);
        $.getJSON(url,function(data)
        {
          // alert("inside");
          $("#charname").html(data.name);
          $("#charregion").html(data.region);
          $("#charcoatOfArms").html(data.coatOfArms);
          $("#charwords").html(data.words);
          $("#chartitles").html(data.titles);
          $("#charseats").html(data.seats);
          $("#charancestralWeapons").html(data.ancestralWeapons);

        });

      }

      function fillTablebyRandomCharacterofHouse()
      {
        DeleteRows();
        alert("inside req func ");
        var name=document.getElementById("searchtext").value;
        // alert("Search bar has "+name);
        name.replace(/ /g,"+");
        var url="https://anapioficeandfire.com/api/houses/?name="+name;
         alert(url);
      
        $.getJSON(url, function(data)
        {
          var a=data[0].swornMembers.length;
          alert("it has "+a+"swornMembers");
          var count = data[0].swornMembers.length;
          // alert(count);
          i = Math.floor(Math.random()*(count-1)+ 1);
          // alert("random"+i);
          urlnew = data[0].swornMembers[i];
          // alert(urlnew);
          $.getJSON(urlnew,function(data)
        {
          // alert("inside");

          $("#charname").html(data.name);
          $("#chargender").html(data.gender);
          $("#charculture").html(data.culture);
          $("#charborn").html(data.born);
          $("#chardied").html(data.died);
          $("#charaliases").html(data.aliases);
          $("#charfather").html(data.father);
          $("#charmother").html(data.mother);
          $("#charspouse").html(data.spouse);
           $("#chartitle").html(data.titles);
     


        });


      });




      }