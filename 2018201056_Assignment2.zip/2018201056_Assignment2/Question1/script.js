function eraseTextArea() {
    document.getElementById("input").value = "";
    eraseIframe();
}
function runCode() {
var content = document.getElementById("input").value;
var iframe = document.getElementById("output");
iframe = (iframe.contentWindow)?iframe.contentWindow:(iframe.contentDocument)? iframe.contentDocument.document: 
iframe.contentDocument;
 
iframe.document.open();
iframe.document.write(content);
iframe.document.close();
return false;
}
function eraseIframe() {
    var iframe = document.getElementById("output");
    var html = "";

iframe.contentWindow.document.open();
iframe.contentWindow.document.write(html);
iframe.contentWindow.document.close();
}
function fun(){
	document.getElementById("output").contentDocument.body.innerHTML=document.getElementById("input").value;
}