
function run_Clock(d){};

function run_Clock(d){
  var secHand = document.getElementById("shand").style;
  var minHand = document.getElementById("mhand").style;
  var hrHand = document.getElementById("hhand").style;
  var h,m,s;
  s=6*(d.getSeconds());
  h=30*(d.getHours()+d.getMinutes()/60);
  m=6*(d.getMinutes());
	secHand.transform = "rotate(" + s + "deg)";
  hrHand.transform = "rotate(" + h + "deg)";
  minHand.transform = "rotate(" + m + "deg)"; 
}

setInterval(function(){
  var d = new Date();
  run_Clock(d);
}, 1000);
