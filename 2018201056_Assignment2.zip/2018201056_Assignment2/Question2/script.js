function getLatest(){
            $.getJSON("https://xkcd.com/info.0.json", function(output){              
                var path_img=output.img;
                id_p=output.num;
                document.getElementById("comic").src=path_img;
                document.getElementById("id_p").innerHTML=id_p;
                var titly = output.title;
                $("p").html(titly);
            
        });
    }
function getFirst(){
            $.getJSON("https://xkcd.com/1/info.0.json", function(output){              
                var path_img=output.img;
                id_p=output.num;
                document.getElementById("comic").src=path_img;
                document.getElementById("id_p").innerHTML=id_p;
                var titly = output.title;
                $("p").html(titly);
            
        });
    }
function getPrevious()
    {
        if(id_p > 1)
        {
            id_p = id_p - 1;
            var temp="https://xkcd.com/"+id_p+"/info.0.json";
            $.getJSON(temp, function(output){
            var path_img=output.img;
            document.getElementById("comic").src=path_img; 
            var titly = output.title;
            $("p").html(titly);

                    
            });
        }
     }
function getNext()
    {
         $.getJSON("https://xkcd.com/info.0.json", function(output)
         {              
                id_last=output.num;
         });
        if(id_p < id_last)
        {
            id_p = id_p + 1;
            var temp="https://xkcd.com/"+id_p+"/info.0.json";
            $.getJSON(temp, function(output){
            var path_img=output.img;
            document.getElementById("comic").src=path_img; 
            var titly = output.title;
            $("p").html(titly);

                    
            });
        }
     }
function getRandom()
{
      $.getJSON("https://xkcd.com/info.0.json", function(output)
         {              
                max=output.num;
         });
      $.getJSON("https://xkcd.com/1/info.0.json", function(output)
         {              
                min=output.num;
         });
    
     var random=Math.floor(Math.random() * (max - min + 1)) + min;
     var url="https://xkcd.com/"+random+"/info.0.json";
       $.getJSON(url, function(output){              
                var path_img=output.img;
                id_p=output.num;
                document.getElementById("comic").src=path_img;
                document.getElementById("id_p").innerHTML=id_p;
                var titly = output.title;
                $("p").html(titly);
            
        });
    
}